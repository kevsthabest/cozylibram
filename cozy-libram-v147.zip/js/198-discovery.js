'use strict';

/* ---------------- new-release discovery (v114, reworked v135) ---------------- */
// "Check for new releases": for each of her top authors, queries Hardcover's
// books table directly for future-dated books by that author (ordered by
// release date), and offers them as one-tap adds into the Wishlist's Coming
// soon section. Dismissed suggestions never come back.
//
// v135 rework: the original swept each author's 10 most *relevant* books via
// the Typesense search endpoint — for an established author that's the
// popular backlist, so upcoming titles almost never appeared and the check
// usually found nothing. The books-table query below asks for future
// release dates explicitly. Query shape verified against Hardcover's public
// GraphQL docs (books → contributions → author → name, release_date filter,
// order_by release_date).

const REL_DISMISS_KEY = 'spicyshelves.dismissed_releases';

function dismissedReleases() {
  try { return new Set(JSON.parse(localStorage.getItem(REL_DISMISS_KEY) || '[]')); }
  catch (e) { return new Set(); }
}
function dismissRelease(hcId) {
  try {
    const arr = JSON.parse(localStorage.getItem(REL_DISMISS_KEY) || '[]');
    arr.push('hc:' + hcId);
    localStorage.setItem(REL_DISMISS_KEY, JSON.stringify(arr.slice(-200)));
  } catch (e) {}
}
function isReleaseDismissed(hcId) { return dismissedReleases().has('hc:' + hcId); }

// Authors ranked by shelf count, then by her average rating of them.
function topReleaseAuthors(limit) {
  const map = {};
  library.forEach(b => {
    (b.authors || []).forEach(a => {
      const k = String(a || '').trim();
      if (!k) return;
      const e = map[k] || (map[k] = { name: k, n: 0, stars: 0, sn: 0 });
      e.n++;
      if (b.myRating > 0) { e.stars += b.myRating; e.sn++; }
    });
  });
  return Object.values(map)
    .sort((x, y) => (y.n - x.n) || ((y.sn ? y.stars / y.sn : 0) - (x.sn ? x.stars / x.sn : 0)))
    .slice(0, limit || 8).map(e => e.name);
}

// Already on her shelves? Matches by ISBN first, then title + first author.
function releaseInLibrary(c) {
  const isbns = (c.isbns || []).map(i => String(i).replace(/[^0-9X]/gi, '')).filter(Boolean);
  if (isbns.length && library.some(b => b.isbn && isbns.indexOf(b.isbn) !== -1)) return true;
  const t = String(c.title || '').toLowerCase().trim();
  const a = String((c.authors || [])[0] || '').toLowerCase().trim();
  if (!t) return false;
  return library.some(b => String(b.title || '').toLowerCase().trim() === t &&
    String((b.authors || [])[0] || '').toLowerCase().trim() === a);
}

function hcBookToCandidate(b) {
  const names = (b.contributions || []).map(x => String((((x || {}).author) || {}).name || '')).filter(Boolean);
  const ed = b.default_physical_edition || {};
  return {
    hcId: b.id,
    title: b.title || 'Untitled',
    authors: names.slice(0, 3),
    releaseDate: String(b.release_date || '').slice(0, 10),
    cover: (b.image && b.image.url) || '',
    description: b.description || '',
    pages: b.pages || null,
    isbns: ed.isbn_13 ? [String(ed.isbn_13)] : []
  };
}

async function checkNewReleases(onTick) {
  const authors = topReleaseAuthors(8);
  const out = [];
  const seen = new Set();
  const d = new Date();
  const today = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  let failed = 0;
  for (let i = 0; i < authors.length; i++) {
    const a = authors[i];
    if (onTick) onTick(a, i + 1, authors.length);
    try {
      const q = 'query { books(where: {contributions: {author: {name: {_eq: ' + JSON.stringify(a) + '}}},' +
        ' release_date: {_gt: "' + today + '"}, canonical_id: {_is_null: true}},' +
        ' order_by: {release_date: asc}, limit: 10)' +
        ' { id title description release_date pages image { url }' +
        ' contributions { author { name } } default_physical_edition { isbn_13 } } }';
      const data = await hcGraphQL(q);
      ((data || {}).books || []).forEach(b => {
        if (b.id == null || seen.has(b.id) || isReleaseDismissed(b.id)) return;
        const c = hcBookToCandidate(b);
        if (!c.releaseDate || c.releaseDate <= today) return; // defensive: the server filters too
        seen.add(b.id);
        if (releaseInLibrary(c)) return;
        out.push(c);
      });
    } catch (e) { failed++; /* one author failing never kills the sweep */ }
    await new Promise(r => setTimeout(r, 700)); // share the Hardcover pacing
  }
  out.sort((x, y) => x.releaseDate.localeCompare(y.releaseDate));
  return { list: out, failed: failed, total: authors.length };
}

function addReleaseBook(c) {
  const clean = (c.isbns || []).map(i => String(i).replace(/[^0-9X]/gi, '')).filter(Boolean);
  const book = {
    id: uid(),
    isbn: clean.find(i => i.length === 13) || clean[0] || '',
    title: c.title, authors: c.authors, cover: c.cover, description: c.description,
    pageCount: c.pages, publishedDate: '', releaseDate: c.releaseDate,
    categories: [], publicRating: null, ratingsCount: 0,
    status: 'tbr', owned: false, ratings: {}, myRating: 0,
    tropes: [], tropesAuto: [], progress: 0,
    dateAdded: new Date().toISOString(), dateFinished: null, notes: '',
    hcId: c.hcId, hcEnriched: true // already holds this Hardcover doc's data
  };
  book.axes = autoDetectAxes(book);
  return addBook(book, false, 'discovery');
}

function renderReleaseResults(list) {
  const box = document.getElementById('release-results');
  if (!box) return;
  if (!list.length) {
    box.innerHTML = '<p class="note">No new releases found — you\'re all caught up ✨</p>';
    return;
  }
  box.innerHTML = '<h3 class="wish-section">' + icon('sparkles') + ' New from your authors</h3>' +
    '<div class="grid">' + list.map((c, i) =>
      '<div class="book-card rel-card" data-i="' + i + '">' + coverHTML(c) +
      '<div class="book-meta"><h3>' + esc(c.title) + '</h3>' +
      '<p class="author">' + esc(c.authors.join(', ')) + '</p>' +
      '<div class="up-pill">' + icon('calendar') + ' ' + esc(fmtDate(c.releaseDate)) + ' · ' + releaseCountdown(c.releaseDate) + '</div>' +
      '</div><div style="align-self:center;display:flex;gap:6px">' +
      '<button class="btn small" data-add="' + i + '">＋ Add</button>' +
      '<button class="btn ghost small" data-dis="' + i + '" aria-label="Dismiss">✕</button></div></div>'
    ).join('') + '</div>';
  box.querySelectorAll('[data-add]').forEach(btn => btn.addEventListener('click', e => {
    e.stopPropagation();
    const c = list[Number(btn.dataset.add)];
    if (addReleaseBook(c)) {
      btn.closest('.rel-card').style.opacity = '0.4';
      btn.textContent = '✓ Added';
      btn.disabled = true;
    }
  }));
  box.querySelectorAll('[data-dis]').forEach(btn => btn.addEventListener('click', e => {
    e.stopPropagation();
    dismissRelease(list[Number(btn.dataset.dis)].hcId);
    btn.closest('.rel-card').remove();
    if (!box.querySelector('.rel-card')) box.innerHTML = '<p class="note">All caught up ✨</p>';
  }));
}

// Wishlist wiring: runs the sweep with progress on the button.
function wireReleaseCheck() {
  const btn = document.getElementById('rel-check');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    if (!hcReady()) { toast('Connect Hardcover in Settings → Hardcover first'); return; }
    track('release_discovery_opened');
    btn.disabled = true;
    const label = btn.innerHTML;
    try {
      const res = await checkNewReleases((a, i, n) => {
        btn.innerHTML = icon('hourglass') + ' Checking ' + esc(a) + '… (' + i + '/' + n + ')';
      });
      const box = document.getElementById('release-results');
      // v135: if every author's lookup failed, say so — "all caught up"
      // would be a lie when we never actually reached Hardcover.
      if (!res.list.length && res.total > 0 && res.failed >= res.total && box) {
        box.innerHTML = '<p class="note">Couldn\'t reach Hardcover for any author — ' +
          'check the connection in Settings → Hardcover, then try again.</p>';
      } else {
        renderReleaseResults(res.list);
      }
    } catch (e) {
      const box = document.getElementById('release-results');
      if (box) box.innerHTML = '<p class="note">The check failed — try again in a bit.</p>';
    } finally {
      btn.disabled = false;
      btn.innerHTML = label;
    }
  });
}

/* ---------------- Discover landing (v121) ----------------
   "What are you in the mood for?" — one destination for every discovery
   feature, each with a plain-language explanation. Cards route to real
   features only; the release check runs inline. */
function discCard(ic, title, blurb, target) {
  return '<button class="disc-card" data-disc="' + target + '">' +
    '<span class="disc-ic">' + icon(ic) + '</span>' +
    '<span class="disc-tx"><b>' + esc(title) + '</b><small>' + esc(blurb) + '</small></span>' +
    '<span class="disc-go" aria-hidden="true">→</span></button>';
}

function renderDiscover() {
  track('discover_opened', null, { dedupeKey: 'discover-open', dedupeMs: 8000 });
  setView('<div class="view-head"><h2 class="serif">' + icon('sparkles') + ' Discover</h2>' +
    '<p class="note">What are you in the mood for?</p></div>' +
    '<div class="disc-list">' +
    discCard('dice', 'Surprise Me', 'Can\u2019t decide what to read? Let Cozy Libram pick something from your TBR.', 'pick') +
    discCard('calendar', 'New Releases', 'Fresh and upcoming books from your favorite authors.', 'releases') +
    discCard('user', 'Authors You Might Like', 'Find missing books from authors you already love.', 'authors') +
    discCard('friends', 'From Friends', 'Books your coven couldn\u2019t put down.', 'coven') +
    discCard('search', 'Search Books', 'Search millions of titles to add to your library.', 'search') +
    '</div>' +
    '<div class="disc-releases"><button class="btn sm" id="rel-check">' + icon('sparkles') + ' Check for new releases</button>' +
    '<div id="release-results"></div></div>');
  wireReleaseCheck();
  document.querySelectorAll('[data-disc]').forEach(c => c.addEventListener('click', () => {
    const t = c.dataset.disc;
    if (t === 'pick') go('pick');
    else if (t === 'authors') go('authors');
    else if (t === 'coven') go('coven');
    else if (t === 'releases') { // v134: the card itself runs the release check
      const b = document.getElementById('rel-check');
      if (b) b.click();
    }
    else if (t === 'search') { addTab = 'search'; go('add'); }
  }));
}
